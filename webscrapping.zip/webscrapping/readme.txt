pip install bs4

pip install requests