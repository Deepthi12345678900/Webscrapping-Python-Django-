from django.contrib import admin

from myapp.models import AllWord, TotalMatchWord

# Register your models here.
admin.site.register(AllWord)
admin.site.register(TotalMatchWord)
